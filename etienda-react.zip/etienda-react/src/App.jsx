// App.jsx
import React, { useState } from 'react';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";
import ProductList from './components/ProductList';
import Navbar from './components/Navbar';

const App = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');

  const handleSearch = async() => {
    setSelectedCategory(null)
  }
  const handleCategoryClick = (category) => {
    setSelectedCategory(category);
  };

  return (
    <div>
      <Navbar 
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        handleSearch={handleSearch}
        onCategoryClick={handleCategoryClick}
      />
      <ProductList searchTerm={searchTerm} selectedCategory={selectedCategory} />
    </div>
  );
};

export default App;
