// Navbar.jsx
import React from 'react';
import SearchBar from './SearchBar';
import './Navbar.css'

const Navbar = ({ searchTerm, setSearchTerm, handleSearch, onCategoryClick }) => {
    const handleClickCategory = (category) => {
        // Llama a la función proporcionada cuando se hace clic en una categoría
        onCategoryClick(category);
    };

    return (
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <p class="navbar-brand" href="#">E-tienda</p>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-2">
                <li class="nav-item">
                    <button onClick={() => handleClickCategory("women's clothing")}>Women's Fashion</button>
                </li>
            </ul>

            <ul class="navbar-nav ml-2">
                <li class="nav-item">
                    <button onClick={() => handleClickCategory("men's clothing")}>Men's Fashion</button>
                </li>
            </ul>

            <ul class="navbar-nav ml-2">
                <li class="nav-item">
                    <button onClick={() => handleClickCategory("jewelery")}>Jewelery</button>
                </li>
            </ul>

            <ul class="navbar-nav ml-2">
                <li class="nav-item">
                <button onClick={() => handleClickCategory("electronics")}>Electronics</button>
                </li>
            </ul>
            
            <ul class="navbar-nav my-2 my-lg-0 ml-auto">
                <li class="nav-item">
                <SearchBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} handleSearch={handleSearch} />
                </li>
            </ul>

        </div>
    </nav>
  );
};

export default Navbar;
