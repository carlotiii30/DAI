import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ProductList = ({ searchTerm, selectedCategory, selectedAll }) => {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        let apiUrl = 'http://localhost:8000/etienda/api/productos'; // Actualiza con la URL de tu API
        if (selectedCategory) {
          apiUrl += `/categoria/${encodeURIComponent(selectedCategory)}`;
        } else if (searchTerm) {
          apiUrl += `/buscar/${searchTerm}`;
        }

        const response = await axios.get(apiUrl);

        setProducts(response.data);
      } catch (error) {
        console.error('Error fetching products:', error);
      }
    };

    fetchProducts();
  }, [searchTerm, selectedCategory]);

  return (
    <div>
      {products.map((producto) => (
        <div key={producto.id} className="col-lg-3 col-md-4 col-sm-6 col-12 mb-4" data-product-id={producto.id}>
          <div className="card">
            <img src={producto.image} alt={producto.title} className="card-img-top img-fluid w-100" />
            <div className="card-body">
              <h3 className="card-title">{producto.title}</h3>
              <p className="card-text">{producto.description}</p>
              <p className="card-text">Price: ${producto.price}</p>
              <p className="card-text">Category: {producto.category}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
